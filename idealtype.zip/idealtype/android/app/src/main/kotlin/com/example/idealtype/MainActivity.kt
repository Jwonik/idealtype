package com.example.idealtype

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
